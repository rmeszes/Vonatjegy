#ifndef STRING_TEST_H
#define STRING_TEST_H

int string_tests();

#endif
